<?php

declare(strict_types=1);

// This file is only here so that the PHP8 attribute for doesn't throw an error in files
// phpcs:ignoreFile PSR1.Classes.ClassDeclaration.MissingNamespace
class ReturnTypeWillChange
{
}
